package com.lab.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lab.dto.BikeReqDto;
import com.lab.service.BikeService;

@RestController
@RequestMapping("/bile")
public class BikeController {
	@Autowired
	private BikeService bikeService;
	
	
	@PostMapping
	public String addBike(BikeReqDto dto) {
		return bikeService.addBike(dto);
		
	}

}
