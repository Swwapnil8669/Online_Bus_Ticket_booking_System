package com.lab.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lab.dao.BikeDao;
import com.lab.dto.BikeReqDto;
import com.lab.pojos.Bike;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class BikeServiceImpl implements BikeService {

	@Autowired
	private BikeDao bikeDao;
	@Autowired
	private ModelMapper mapper;
	
	public String addBike(BikeReqDto dto) {
		Bike tranBike = mapper.map(dto, Bike.class);
		Bike PerBike = bikeDao.save(tranBike);
		return "bike added with Id" + PerBike.getId();
	}

}
