package com.lab.service;

import com.lab.dto.BikeReqDto;

public interface BikeService {
 String addBike(BikeReqDto dto);
}
