package com.lab.pojos;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Setter
@Getter
@ToString
public class Bike extends BaseEntity{
private String bName;
private String model;
@Column(name = "company_name")
private String companyName;
private boolean status;
}
