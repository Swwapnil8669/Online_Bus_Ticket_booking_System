package com.lab.service;

import com.lab.dto.CustomerReqDto;

public interface CustomerService {
	public String addCustomer(CustomerReqDto dto);
}
