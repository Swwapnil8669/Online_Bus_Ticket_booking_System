package com.lab.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lab.dao.CustomerDao;
import com.lab.dto.CustomerReqDto;
import com.lab.pojos.Customer;

import jakarta.transaction.Transactional;
@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {
@Autowired
private CustomerDao customerDao;
@Autowired
private ModelMapper mapper;
	
	
	public String addCustomer(CustomerReqDto dto) {
		Customer tranCust = mapper.map(dto, Customer.class);
		Customer PerCust = customerDao.save(tranCust);
		return "customer added with id "+ PerCust.getId() ;
	}

	

}
