package com.lab.pojos;

import java.sql.Date;



import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Entity
@Setter
@Getter
@ToString
public class BookingDetails extends BaseEntity{
	private Date pickupDate;
	private Date dropDate;
	private long price;
	private String address;
	@ManyToOne
	@JoinColumn(name = "user_id")
	private Customer customer;
	@ManyToOne
	@JoinColumn(name = "bike_id")
	private Bike bike;

}
