package com.lab.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lab.pojos.Bike;

public interface BikeDao extends JpaRepository<Bike, Long> {

}
