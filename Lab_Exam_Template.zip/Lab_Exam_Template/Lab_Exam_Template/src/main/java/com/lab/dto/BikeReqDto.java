package com.lab.dto;



import jakarta.persistence.Column;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;



	@Setter
	@Getter
	@ToString
	public class BikeReqDto {
	private String bName;
	private String model;
	private String companyName;
	private boolean status;
	}

